<?php

require_once 'Pessoa.php';
require_once 'Matricula.php';

class Aluno extends Pessoa {
    protected $dataNascimento;
    protected $matricula;

    public function __construct($nome, $cpf, $dataNascimento) {
        parent::__construct($nome, $cpf);
        $this->dataNascimento = $dataNascimento;
    }

    public function getDataNascimento() {
        return $this->dataNascimento;
    }

    public function setMatricula($matricula) {
        $this->matricula = $matricula;
    }

    public function getMatricula() {
        return $this->matricula;
    }

    public function getModalidade() {
        return "Modalidade do Aluno";
    }
}
?>
