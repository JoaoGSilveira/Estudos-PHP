<?php

class Modalidade {
    protected $descritivo;

    public function __construct($descritivo) {
        $this->descritivo = $descritivo;
    }

    public function getDescritivo() {
        return $this->descritivo;
    }
}
?>