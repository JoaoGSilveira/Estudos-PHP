<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 01/04/24</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #dddddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Professores</h1>
        <table>
            <tr>
                <th>Nome</th>
                <th>CPF</th>
                <th>Título</th>
                <th>Modalidade</th>
            </tr>
            <?php
            require_once 'Professor.php';

            $professores_data = array(
                array("Anderson", "638.578.828-83", "Renshi", "Judô"),
                array("Thiago", "053.533.523-78", "Kioshi", "Aikidô"),
                array("Matheus", "661.343.317-91", "Shihan-Hanshi", "Karate")
            );

            foreach ($professores_data as $professor_data) {
                $professor = new Professor($professor_data[0], $professor_data[1]);
                $professor->setTitulo($professor_data[2]);
                echo "<tr>";
                echo "<td>" . $professor->getNome() . "</td>";
                echo "<td>" . $professor->getCPF() . "</td>";
                echo "<td>" . $professor->getTitulo() . "</td>";
                echo "<td>" . $professor_data[3] . "</td>";
                echo "</tr>";
            }
            ?>
        </table>

        <h1>Alunos</h1>
        <table>
            <tr>
                <th>Nome</th>
                <th>CPF</th>
                <th>Data de Nascimento</th>
                <th>Data de Matrícula</th>
                <th>Modalidade</th>
            </tr>
            <?php
            require_once 'Aluno.php';
            require_once 'Matricula.php';

            $alunos_data = array(
                array("Maria", "192.798.443-26", "1990-05-15"),
                array("João", "237.270.676-40", "1992-08-20"),
                array("Ana", "101.757.193-73", "1995-02-10"),
                array("Pedro", "714.431.658-32", "1998-11-25"),
                array("Lucas", "522.163.419-83", "2000-09-03"),
                array("Carla", "718.971.261-58", "2003-04-18"),
                array("Fernanda", "614.220.747-65", "2005-07-22"),
                array("Marcos", "687.140.728-66", "2008-01-30"),
                array("Julia", "589.680.553-51", "2008-06-07"),
                array("Rafael", "871.661.042-36", "2008-03-12")
            );

            $modalidades_alunos = array("Judô", "Aikidô", "Karate");

            $matriculas_data = array(
                "2020-02-01", "2021-03-09", "2022-11-24", "2020-10-03", "2022-01-07",
                "2023-04-16", "2022-04-20", "2024-08-23", "2021-03-28", "2023-12-01"
            );

            foreach ($alunos_data as $key => $aluno_data) {
                $aluno = new Aluno($aluno_data[0], $aluno_data[1], $aluno_data[2]);
                $matricula = new Matricula($matriculas_data[$key]);
                $aluno->setMatricula($matricula);
                $modalidade_aluno = $modalidades_alunos[$key % count($modalidades_alunos)];
                echo "<tr>";
                echo "<td>" . $aluno->getNome() . "</td>";
                echo "<td>" . $aluno->getCPF() . "</td>";
                echo "<td>" . str_replace('-', '/', $aluno->getDataNascimento()) . "</td>";
                echo "<td>" . str_replace('-', '/', $aluno->getMatricula()->getDataMatricula()) . "</td>";
                echo "<td>" . $modalidade_aluno . "</td>";
                echo "</tr>";
            }
            ?>
        </table>

        <h1>Funcionários</h1>
        <table>
            <tr>
                <th>Nome</th>
                <th>CPF</th>
                <th>Cargo</th>
            </tr>
            <?php
            require_once 'Funcionario.php';

            $funcionarios_data = array(
                array("José", "436.273.569-00", "Secretário"),
                array("Maria", "961.035.546-32", "Auxiliar Administrativo"),
                array("João", "143.861.127-74", "Técnico de Informática")
            );

            foreach ($funcionarios_data as $funcionario_data) {
                $funcionario = new Funcionario($funcionario_data[0], $funcionario_data[1], $funcionario_data[2]);
                echo "<tr>";
                echo "<td>" . $funcionario->getNome() . "</td>";
                echo "<td>" . $funcionario->getCPF() . "</td>";
                echo "<td>" . $funcionario->getCargo() . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</body>

</html>