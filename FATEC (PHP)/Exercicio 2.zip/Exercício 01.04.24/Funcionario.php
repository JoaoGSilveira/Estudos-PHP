<?php

require_once 'Pessoa.php';

class Funcionario extends Pessoa {
    protected $cargo;

    public function __construct($nome, $cpf, $cargo) {
        parent::__construct($nome, $cpf);
        $this->cargo = $cargo;
    }

    public function getCargo() {
        return $this->cargo;
    }
}
?>