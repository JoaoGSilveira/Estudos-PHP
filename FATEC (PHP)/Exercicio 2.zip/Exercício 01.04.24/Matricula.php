<?php

class Matricula {
    protected $dataMatricula;

    public function __construct($dataMatricula) {
        $this->dataMatricula = $dataMatricula;
    }

    public function getDataMatricula() {
        return $this->dataMatricula;
    }
}
?>