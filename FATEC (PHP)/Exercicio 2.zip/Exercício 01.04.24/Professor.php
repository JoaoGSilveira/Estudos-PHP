<?php

require_once 'Pessoa.php';

class Professor extends Pessoa {
    protected $titulo;

    public function __construct($nome, $cpf) {
        parent::__construct($nome, $cpf);
    }

    public function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    public function getModalidade() {
        $modalidades = array(
            "Renshi" => "Judô",
            "Kioshi" => "Aikidô",
            "Shihan-Hanshi" => "Karate"
        );

        if (isset($modalidades[$this->titulo])) {
            return $modalidades[$this->titulo];
        } else {
            return "N/A";
        }
    }
}
?>
